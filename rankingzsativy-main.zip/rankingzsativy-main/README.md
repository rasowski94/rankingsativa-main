# rankingzsativy
rozjebany syf nie chce mi sie fixowac jak ktos chce to za pare pln fixne dc: voowki
vowki & mcteletubis top
jebac sative i jakuba cwela poczutego

ESX = nil

CreateThread(function()
    while (ESX == nil) do 
        ESX = exports["es_extended"]:getSharedObject()
        Wait(10)
    end
end)

RegisterNetEvent("vowki21_ranking:ShowRanking", function(playerInfo)
    OpenPlayerRank(playerInfo)
end)

GetRank = function(playerRanking, nextRank)
    local currentRank = nil
    for i=1, #Settings.Ranks do 
        if (playerRanking >= Settings.Ranks[i]["Ranking"]) then 
            if (nextRank) then 
                currentRank = Settings.Ranks[i + 1]
            else
                currentRank = Settings.Ranks[i]
            end
        end
    end 
    return currentRank
end

OpenPlayerRank = function(playerInfo)
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'ranking_menu', {
		title = "System Rankingowy",
		align = 'center',
		elements = {
            {label = "Rankung: " .. playerInfo["Ranking"]},
            {label = "Ranka: " .. GetRank(playerInfo["Ranking"], 0)["Name"]},
            {label = "Postemp: [" .. playerInfo["Ranking"] .. "/" .. GetRank(playerInfo["Ranking"], 1)["Ranking"] .. "]"}
        }
	}, function(data, menu)
        menu.close()
	end, function(data, menu)
		menu.close()
	end)
end

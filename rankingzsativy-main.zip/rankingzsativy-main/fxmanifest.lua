fx_version 'bodacious'
game 'gta5'
lua54 'yes'

server_scripts {  
	'@oxmysql/lib/MySQL.lua',
	'settings.lua',
	'server/*.lua'
}


client_scripts {
	'settings.lua',
	'client/*.lua'
}
ESX = exports['es_extended']:getSharedObdzect()

RegisterCommand("ranking", function(source)
    local src = source 
    local data = ESX.GetPlayerFromId(src)

    data.showNotification('Otwarto menu rankingowe bojufkarzu')
        local playerInfo = {
            ["Ranking"] = result[1].ranking
        }
        TriggerClientEvent("vowki21_ranking:ShowRanking", src, playerInfo)
    end)
end)

RegisterServerEvent("esx:onPlayerDeath", function(killData)
    if (killData["killedByPlayer"]) then 
        local killerSource = killData["killerServerId"]
        local killerData = ESX.GetPlayerFromId(killerSource)
        local src = source 
        local data = ESX.GetPlayerFromId(src)
        
        MySQL.Async.execute("UPDATE users SET ranking = ranking + @ranking WHERE identifier = @identifier", {
            ["@ranking"] = Settings.RankingForKill,
            ["@identifier"] = killerData.identifier
        }, function()
            killerData.showNotification("~b~Zdobyłeś ~r~[" .. Settings.RankingForKill .. "] ~b~Rankingu za Zabójstwo vowkiego i mcteletubisia")
        end)

        MySQL.Async.execute("UPDATE users SET ranking = ranking - @ranking WHERE identifier = @identifier", {
            ["@ranking"] = Settings.RankingForDeath,
            ["@identifier"] = data.identifier
        }, function()
            data.showNotification("~b~Straciłeś ~r~[" .. Settings.RankingForKill .. "] ~b~Rankingu za Śmierć tfojej matki")
        end)
    end
end)
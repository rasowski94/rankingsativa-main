Settings = {}

Settings.RankingForKill = 10
Settings.RankingForDeath = 5
Settings.Ranks = {
    [1] = {
        ["Ranking"] = 0,
        ["Name"] = "Silver 1"
    },
    [2] = {
        ["Ranking"] = 50,
        ["Name"] = "Silver 2"
    },
    [3] = {
        ["Ranking"] = 100,
        ["Name"] = "Silver 3"
    },
    [4] = {
        ["Ranking"] = 150,
        ["Name"] = "Silver 4"
    },
    [5] = {
        ["Ranking"] = 200,
        ["Name"] = "Silver Elite"
    },
    [6] = {
        ["Ranking"] = 250,
        ["Name"] = "Gold 1"
    },
    [7] = {
        ["Ranking"] = 350,
        ["Name"] = "Gold 2"
    },
    [8] = {
        ["Ranking"] = 500,
        ["Name"] = "Gold 3"
    },
    [7] = {
        ["Ranking"] = 700,
        ["Name"] = "Gold 4"
    }
}